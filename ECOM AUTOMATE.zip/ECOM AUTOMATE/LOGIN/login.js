import { Selector } from 'testcafe';
import { ClientFunction } from 'testcafe';


const signIn = Selector('#button').withText('SIGN IN');
const emaild = Selector('input#identifierId');
const heading = Selector('h1');
const NextButton = Selector('button').withText('Next');
const pwd = Selector('div').withText('Enter your password');
const nextbutton2 = Selector('button').withText('Next');
const search = Selector('input#search');
const searchbutton = Selector('button#search-icon-legacy');
const filter = Selector('yt-formatted-string').withText('FILTERS');
const video = Selector('yt-formatted-string').withText('Video');
const hovers = Selector('.style-scope ytd-guide-entry-renderer');
const element = Selector('#items');
const scrollBy = ClientFunction(() => {
  window.scrollBy(0, 2000);
});

fixture `Getting started from the beginning`
   .page `https://www.youtube.com`



   test('My Youtube channel' , async t => {
        
    await t
          .maximizeWindow()
        //   .click(signIn)
        //   .expect(heading.exists).ok()
        //   .typeText(emaild , 'shikhasharma0698@gmail.com')
        //   .click(NextButton)
        //   .wait(2000)
        //   .typeText(pwd, 'bea1stsmart')
        //   .click(nextbutton2)
        //   .wait(2000);

          .typeText(search , 'how to automate website using testcafe')
          .expect(search.value).contains('how to automate website using testcafe', 'input contains text "how to automate website using testcafe"')
          .click(searchbutton)
          .wait(2000)
          .click(filter)
          .wait(2000)
          .click(video)
           .wait(2000)
           .hover(hovers);
          //  .takeScreenshot('ss.png')
           await scrollBy();

   });
